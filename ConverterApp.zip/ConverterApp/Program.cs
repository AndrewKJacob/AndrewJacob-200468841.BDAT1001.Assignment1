﻿using System;
using System.Linq;

namespace ConverterApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //ASCII to Binary
            Console.WriteLine("Enter your name: ");

            var fullName = Console.ReadLine();

            string binaryValue = Converter.StringToBinary(fullName);

            Console.WriteLine($"Text: {fullName}\nBinary: {binaryValue}");

            //Binary to ASCII
            Console.WriteLine("Enter Binary version of your name: ");

            var ascii = Console.ReadLine();

            string asciiValue = Converter.BinaryToString(ascii);

            Console.WriteLine($"Binary: {ascii}\nText: {asciiValue}");

            //ASCII to Hexadecimal
            Console.WriteLine("Enter your name: ");

            fullName = Console.ReadLine();

            string hexValue = Converter.StringToHex2(fullName);

            Console.WriteLine($"Hex: {hexValue}\nText: {fullName}");

            //Hexadecimal to ASCII
            Console.WriteLine("Enter Hexadecimal version of your name: ");

            ascii = Console.ReadLine();

            string asciiValue2 = Converter.HexToString(ascii);

            Console.WriteLine($"Hexadecimal: {ascii}\nText: {asciiValue2}");

            //ASCII to Base64
            Console.WriteLine("Enter your name: ");

            fullName = Console.ReadLine();

            string nameBase64Encoded = Converter.StringToBase64(fullName);

            Console.WriteLine($"Base64: { nameBase64Encoded}");

            //Base64 to ASCII

            Console.WriteLine("Enter Base64 version of your name: ");

            ascii = Console.ReadLine();

            string asciiValue3 = Converter.Base64ToString(ascii);

            Console.WriteLine($"Base64: {ascii}\nText: {asciiValue3}");
            
            //String to Byte Array
            var fullNameBytes =  Converter.StringToByteArray(fullName);
            Console.WriteLine($"Full name in byte array: {fullNameBytes}");
            //Deep Encrypt / Decrypt with cipher

            int[] cipher = new[] { 1, 1, 2, 3, 5, 8, 13 }; //Fibonacci Sequence
            string cipherasString = String.Join(",", cipher.Select(x => x.ToString())); //FOr display
            int encryptionDepth = 20;

            string nameDeepEncryptWithCipher = Converter.DeepEncryptWithCipher(fullName, cipher, encryptionDepth);
            Console.WriteLine($"Deep Encrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepEncryptWithCipher}");
            
            string nameDeepDecryptWithCipher = Converter.DeepDecryptWithCipher(nameDeepEncryptWithCipher, cipher, encryptionDepth);
            Console.WriteLine($"Deep Decrypted {encryptionDepth} times using the cipher {{{cipherasString}}} {nameDeepDecryptWithCipher}");

        }
    }
}
